<p>
<img src= "https://camo.githubusercontent.com/71b837571c48af3aa60a73dbc9d5936aa359d78efbfa8a6743cbbbc16b80ef4d/68747470733a2f2f63646e2e646973636f72646170702e636f6d2f6174746163686d656e74732f3830353930323039333930363630383138362f3830353931333937323533353539303932322f74656e6f722e676966"/>
</p>

<p align="center" ><img alt="SpamReport" src="https://raw.githubusercontent.com/MicaelliMedeiros/micaellimedeiros/master/image/computer-illustration.png"></p>

<h1 align="center">SpamReport (Alpha)</h1>
<p align="center">
  <img alt="GitHub commit activity" src="https://img.shields.io/github/commit-activity/m/Kiny-Kiny/SpamReport">
  <img alt="Latest version" src="https://img.shields.io/github/v/release/Kiny-Kiny/SpamReport.svg" alt="Latest version">

  <p align="center">
    Este script foi feito apenas para uso educacional, não me responsabilizo por qualquer uso indevido.
  </p>
</p>

<h3><p align="center">Version: 1.0 Alpha</p></h3>

![image](https://github.com/Kiny-Kiny/SpamReport/blob/main/IMG-20210803-WA0578.jpg)

![banner](https://github.com/Kiny-Kiny/SpamReport/blob/main/IMG-20210620-WA0488.jpg)
> Ative essa opção no Gmail em que você irá utilizar.

> Obs: usuários de IOS, cliquem aqui [**aqui**](https://myaccount.google.com/lesssecureapps?pli=1&rapt=AEjHL4OSggjYOgt8g8HbgSU58LpUqQ5GsD63ipENqa84YegMHionqqvIXMMoc4bqu-C0GH0N--Kal_AFpd5rRJYyO0g-y1AbEQ)

<p align="center" >
  <h2 align="center">📧 Groups</h2>
<a href="https://chat.whatsapp.com/Lg9Ku0IeMNu4D54Ux3Y2c0" alt="WhatsApp">
  <img src = "https://img.shields.io/badge/-WhatsApp-25d366?style=flat-square&labelColor=25d366&logo=whatsapp&logoColor=white&link=API-DO-SEU-WHATSAPP" /> </a>

<h2 align="center">🖥 Install</h2>

<a href="https://youtu.be/16dNoyWNjXw">Tutorial de Instalação/Uso(Clique Aqui)</a>

```
📱iSH
apk update
apk upgrade
apk add git
apk add python
apk add python2
apk add python3
apk add figlet
git clone https://github.com/Kiny-Kiny/SpamReport
cd SpamReport
python3 -m ensurepip --default-pip
python3 main.py

💻Termux
apt update && apt upgrade -y
apt install git python figlet -y
git clone https://github.com/Kiny-Kiny/SpamReport
cd SpamReport
python3 main.py
```

<p>
<img src= "https://camo.githubusercontent.com/71b837571c48af3aa60a73dbc9d5936aa359d78efbfa8a6743cbbbc16b80ef4d/68747470733a2f2f63646e2e646973636f72646170702e636f6d2f6174746163686d656e74732f3830353930323039333930363630383138362f3830353931333937323533353539303932322f74656e6f722e676966"/>
</p>
